<!DOCTYPE html>
<html>
<head>
    <title>Tentang - Laravel 1</title>
</head>
<body>
    <h1>Tentang Usaha Kami</h1>
    <p>Kami adalah penyedia produk otomotif terbaik di Indonesia.</p>
    <a href="/">Kembali ke Beranda</a>
</body>
</html>