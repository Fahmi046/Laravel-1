<!DOCTYPE html>
<html>
<head>
    <title>Beranda - Laravel 1</title>
</head>
<body>
    <h1>Selamat Datang di Usaha Fahmi</h1>
    <p>Ini adalah halaman beranda Laravel sederhana.</p>
    <a href="/tentang">Tentang Kami</a>
</body>
</html>